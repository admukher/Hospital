package com.cg.entities;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EmployeeDetails")
public class EmployeeDetails {
	@Id
	int id;
	
	private static final long serialVersionUID = 1L;
	
	private String empname;
	private Date dob;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return "EmployeeDetails [id=" + id + ", empname=" + empname + ", dob="
				+ dob + "]";
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
