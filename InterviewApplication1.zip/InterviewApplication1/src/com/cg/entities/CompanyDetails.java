package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="CompanyDetails")
public class CompanyDetails {
	
	@Id
	
	int id1;
	
	
	private String companyname;
	
	
	private String location;
	
	
	private String paypackage;
	
	
	public int getId1() {
		return id1;
	}
	public void setId1(int id1) {
		this.id1 = id1;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPaypackage() {
		return paypackage;
	}
	public void setPaypackage(String paypackage) {
		this.paypackage = paypackage;
	}
	@Override
	public String toString() {
		return "CompanyDetails [id=" + id1+ ", companyname=" + companyname
				+ ", location=" + location + ", paypackage=" + paypackage + "]";
	}
	
	
	

}
