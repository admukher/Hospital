package com.cg.dao;

import java.util.List;

import com.cg.entities.CompanyDetails;



public interface InterviewDao {
	

		public abstract List<CompanyDetails> loadAllCompany();

		public abstract CompanyDetails findCompany(int id);

}
