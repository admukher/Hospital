package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.CompanyDetails;


@Repository
public class InterviewDaoImpl implements InterviewDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public CompanyDetails findCompany(int id) {
		return entityManager.find(CompanyDetails.class,id);
	}

	@Override
	public List<CompanyDetails> loadAllCompany() {
		TypedQuery<CompanyDetails> query = 
				entityManager.
				createQuery
				("SELECT h FROM CompanyDetails h", 
						CompanyDetails.class);
		return query.getResultList();
	}

}
