package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.cg.dao.InterviewDao;
import com.cg.entities.CompanyDetails;

@Service
@Transactional
public class InterviewServiceImpl implements InterviewService{
	
	@Autowired 
	private InterviewDao Dao;

	@Override
	public List<CompanyDetails> loadAllCompany() {
		// TODO Auto-generated method stub
		return Dao.loadAllCompany();
	}

	@Override
	public CompanyDetails findCompany(int id) {
		// TODO Auto-generated method stub
		return Dao.findCompany(id);
	}

}
