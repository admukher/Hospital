package com.cg.service;

import java.util.List;

import com.cg.entities.CompanyDetails;



public interface InterviewService {
	public abstract List<CompanyDetails> loadAllCompany();

	public abstract CompanyDetails findCompany(int id);

	
}
